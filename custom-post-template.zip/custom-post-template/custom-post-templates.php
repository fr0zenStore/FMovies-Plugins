<?php
/*
Plugin Name: Custom Post Templates
Plugin URI: https://fr0zen.store/
Description: Fmovies Themes required Custom Post Templates plugin
Author: fr0zen
Version: 1.9
Author URI: https://fr0zen.store/
*/

require_once dirname( __FILE__ ) . '/plugin.php';
require_once dirname( __FILE__ ) . '/template-tags.php';


class CustomPostTemplates extends CustomPostTemplates_Plugin {

	private $tpl_meta_key;
	private $post_ID;

	function __construct() {

		$this->tpl_meta_key = 'custom_post_template';

		$this->register_plugin( 'custom-post-templates', __FILE__ );
		$this->add_action( 'admin_init' );
		$this->add_action( 'save_post' );
		$this->add_filter( 'single_template', 'filter_single_template' );
		$this->add_filter( 'body_class' );
	}


	public function admin_init() {

		$post_types = apply_filters( 'cpt_post_types', array( 'post' ) );
		foreach ( $post_types as $post_type ) {
			$this->add_meta_box( 'select_post_template', __( 'Post Template', 'custom-post-templates' ), 'select_post_template', $post_type, 'side', 'default' );
		}
	}

	public function body_class( $classes ) {
		if ( ! is_post_template() ) {
			return $classes;
		}
		global $wp_query;

		$post          = $wp_query->get_queried_object();
		$post_template = get_post_meta( $post->ID, 'custom_post_template', true );
		$classes[]     = 'post-template';
		$classes[]     = 'post-template-' . str_replace( '.php', '-php', $post_template );
		return $classes;
	}

	public function select_post_template( $post ) {
		 $this->post_ID = $post->ID;

		$template_vars                    = array();
		$template_vars['templates']       = $this->get_post_templates();
		$template_vars['custom_template'] = $this->get_custom_post_template();


		$this->render_admin( 'select_post_template', $template_vars );
	}

	public function save_post( $post_ID ) {
		if ( empty( $_POST['custom_post_template_present'] ) ) {
			return; }
		$action_needed = (bool) @ $_POST['custom_post_template_present'];
		if ( ! $action_needed ) {
			return;
		}

		$this->post_ID = $post_ID;

		$template = (string) @ $_POST['custom_post_template'];
		$this->set_custom_post_template( $template );
	}

	public function filter_single_template( $template ) {
		global $wp_query;

		$this->post_ID = $wp_query->post->ID;


		$template_file = $this->get_custom_post_template();

		if ( ! $template_file ) {
			return $template;
		}


		if ( file_exists( trailingslashit( STYLESHEETPATH ) . $template_file ) ) {
			return STYLESHEETPATH . DIRECTORY_SEPARATOR . $template_file;
		}

		elseif ( file_exists( TEMPLATEPATH . DIRECTORY_SEPARATOR . $template_file ) ) {
			return TEMPLATEPATH . DIRECTORY_SEPARATOR . $template_file;
		}

		return $template;
	}


	protected function set_custom_post_template( $template ) {
		delete_post_meta( $this->post_ID, $this->tpl_meta_key );
		if ( ! $template || $template == 'default' ) {
			return;
		}

		add_post_meta( $this->post_ID, $this->tpl_meta_key, $template );
	}

	protected function get_custom_post_template() {
		 $custom_template = get_post_meta( $this->post_ID, $this->tpl_meta_key, true );
		return $custom_template;
	}

	protected function get_post_templates() {
		$theme = wp_get_theme();


		$post_templates = array();

		$files = (array) $theme->get_files( 'php', 1 );

		if ( $theme->parent() ) {
			$files += (array) $theme->parent()->get_files( 'php', 1 );
		}


		foreach ( $files as $file => $full_path ) {
			$headers = get_file_data( $full_path, array( 'Template Name Posts' => 'Template Name Posts' ) );
			if ( empty( $headers['Template Name Posts'] ) ) {
				continue;
			}
			$post_templates[ $file ] = $headers['Template Name Posts'];
		}

		return $post_templates;
	}
}
$CustomPostTemplates = new CustomPostTemplates();