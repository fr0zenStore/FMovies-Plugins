<?php


if ( ! function_exists( 'is_post_template' ) ) {
	function is_post_template( $template = '' ) {
		if ( ! is_single() ) {
			return false;
		}

		global $wp_query;

		$post          = $wp_query->get_queried_object();
		$post_template = get_post_meta( $post->ID, 'custom_post_template', true );

		// We have no argument passed so just see if a page_template has been specified
		if ( empty( $template ) ) {
			if ( ! empty( $post_template ) ) {
				return true;
			}
		} elseif ( $template == $post_template ) {
			return true;
		}

		return false;
	}
}



