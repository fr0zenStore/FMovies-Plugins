<?php
/*
Plugin Name: Fmovie Core
Plugin URI: https://fr0zen.store/
Description: Fmovies WordPress Theme Core Plugin.
Version: 5.0.1
Author: fr0zen
Author URI: https://fr0zen.store/
*/
      

// remove
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'feed_links_extra', 3); 
remove_action('wp_head', 'feed_links', 2); 
remove_action('wp_head', 'rsd_link'); 
remove_action('wp_head', 'wlwmanifest_link'); 
remove_action('wp_head', 'index_rel_link'); 
remove_action('wp_head', 'parent_post_rel_link', 10, 0); 
remove_action('wp_head', 'start_post_rel_link', 10, 0); 
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
remove_action('wp_head', 'wp_resource_hints', 2 );
//remove_action( 'admin_notices', 'update_nag', 3 );
remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('admin_print_scripts', 'print_emoji_detection_script' );
remove_action('wp_print_styles', 'print_emoji_styles' );
remove_action('admin_print_styles', 'print_emoji_styles' );
remove_action( 'set_comment_cookies', 'wp_set_comment_cookies' );
//remove_action('wp_head', 'rest_output_link_wp_head', 10 );
//add_filter( 'wpseo_json_ld_output', '__return_false' );
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false', 100 );
add_filter( 'use_widgets_block_editor', '__return_false' );

//next_rel_link
add_filter( 'wpseo_next_rel_link', '__return_false' );
add_filter( 'wpseo_prev_rel_link', '__return_false' );
add_filter('deprecated_constructor_trigger_error', '__return_false');

add_filter( 'use_block_editor_for_post', '__return_false' );
add_filter( 'auto_update_theme', '__return_false' );
add_filter( 'rss_widget_feed_link', '__return_false' );
add_filter( 'rank_math/admin/disable_primary_term', '__return_true' );
add_filter( 'wpseo_next_rel_link', '__return_false' );
add_filter( 'wpseo_prev_rel_link', '__return_false' );



// define
$color_style = get_option( 'admin_color_style' );
define( 'DISQUS_ID', 'movieapp-1' );

if ( $color_style == 'light' ) {
	define( 'PLACEHOLDER', "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 500 750'%3E%3C/svg%3E" );
} else {
define( 'PLACEHOLDER', 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAgA0JaQAA3AA/vv9UAA=' );
}
define( 'PLACEHOLDER_SLIDER', 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAgA0JaQAA3AA/vv9UAA=' );


function taxonomy_init()
{
    register_taxonomy('director', 'post', array(
            'hierarchical' => false, 'label' => 'Directors',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('actors', 'post', array(
            'hierarchical' => false, 'label' => 'Actors',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('country', 'post', array(
            'hierarchical' => false, 'label' => 'Countries',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('years', 'post', array(
            'hierarchical' => false, 'label' => 'Year',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('language', 'post', array(
            'hierarchical' => false, 'label' => 'Language',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('quality', 'post', array(
            'hierarchical' => false, 'label' => 'Quality',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('networks', 'post', array(
            'hierarchical' => false,  'label' => 'Networks',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('creator', 'post', array(
             'hierarchical' => false,  'label' => 'Creators',
             'query_var' => true, 'rewrite' => true));
    } 
add_action('init', 'taxonomy_init', 0);

function unregister_default_widgets() {
unregister_widget('WP_Widget_Block');
unregister_widget('WP_Nav_Menu_Widget');
unregister_widget('WP_Widget_Media_Audio');
unregister_widget('WP_Widget_Media_Image');
unregister_widget('WP_Widget_Media_Video');
unregister_widget('WP_Widget_Media_Gallery');
unregister_widget('WP_Widget_RSS');
unregister_widget('WP_Widget_Recent_Comments');
unregister_widget('WP_Widget_Categories');
unregister_widget('WP_Widget_Calendar');
unregister_widget('WP_Widget_Search');
unregister_widget('WP_Widget_Tag_Cloud');
unregister_widget('Search_Filter_Register_Widget');
}
add_action('widgets_init', 'unregister_default_widgets', 11);

//function wpdocs_remove_menus(){

  //remove_submenu_page( 'themes.php', 'nav-menus.php' );  //Nav Menu

   
//}
//add_action( 'admin_menu', 'wpdocs_remove_menus' );


//Enable upload webp images
function webp_upload_mimes( $existing_mimes ) {
    // add webp to the list of mime types
    $existing_mimes['webp'] = 'image/webp';

    // return the array back to the function with our added mime type
    return $existing_mimes;
}
add_filter( 'mime_types', 'webp_upload_mimes' );
	
	
//Enable preview / thumbnail for webp images
function webp_is_displayable($result, $path) {
    if ($result === false) {
        $displayable_image_types = array( IMAGETYPE_WEBP );
        $info = @getimagesize( $path );

        if (empty($info)) {
            $result = false;
        } elseif (!in_array($info[2], $displayable_image_types)) {
            $result = false;
        } else {
            $result = true;
        }
    }

    return $result;
}
add_filter('file_is_displayable_image', 'webp_is_displayable', 10, 2);





add_action( 'wp_enqueue_scripts', function(){
    if (is_admin()) return; 
    wp_deregister_script( 'jquery' );
    wp_register_script( 'jquery', 'https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.min.js', array(), '3.6.1', true );
    wp_enqueue_script( 'jquery');
});


add_action( 'wp_default_scripts', function( $scripts ) {
    if ( ! empty( $scripts->registered['jquery'] ) ) {
        $scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) );
    }
  } 
);


add_action( 'wp_enqueue_scripts', 'js_to_footer' );

function js_to_footer() {
  remove_action( 'wp_head', 'wp_print_scripts' );
  remove_action( 'wp_head', 'wp_print_head_scripts', 9 );
  remove_action( 'wp_head', 'wp_enqueue_scripts', 1 );
}




add_action( 'wp_enqueue_scripts', 'fmovie_child_deregister_styles', 20 );
function fmovie_child_deregister_styles() {
    wp_dequeue_style( 'classic-theme-styles' );

}

//encodeUrl
function encodeUrl($url) {
 global $post;
 return urlencode( base64_encode( $url ) );
}

//report_content
function report_content() {
global $post;
if (!function_exists('is_plugin_active')) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}
if ( is_plugin_active( 'report-content/report-content.php' ) ) {
    echo wprc_report_submission_form();
} else {
//null
} 
}



add_action('wp_enqueue_scripts', 'remove_sf_scripts', 100);
function remove_sf_scripts(){
	wp_deregister_script( 'jquery-ui-datepicker' );
	//wp_deregister_script( 'search-filter-plugin-build' );
    wp_deregister_script( 'search-filter-plugin-chosen' );
    wp_deregister_script( 'search-filter-plugin-select2' );
	wp_deregister_script( 'search-filter-chosen-script' );
}

add_action('wp_print_styles', 'remove_sf_styles', 100);
function remove_sf_styles(){
    
	wp_dequeue_style( 'search-filter-plugin-styles' );
}

function filter_test($input_object, $sfid)
{

	if($input_object['type']!='checkbox')
	{
		return $input_object;
	}
	$input_object['attributes']['class'] = 'noclose dropdown-menu lg c4';

	return $input_object;
}

add_filter('sf_input_object_pre', 'filter_test', 10, 2);

// remove wp block
function fmovie_remove_wp_block_library_css() {
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
}
add_action( 'wp_enqueue_scripts', 'fmovie_remove_wp_block_library_css' );


function fmovie_remove_global_css() {
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
	remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
}
add_action( 'init', 'fmovie_remove_global_css' );



define( 'IMPORTER_PLUGIN', '/wp-content/plugins/importer-premium/App/public/css' );
function load_fmovies_movie_style($hook) {

        if($hook != 'toplevel_page_fmovies_movie') {
                return;
        }
        wp_enqueue_style( 'fmovies_movie', esc_url( \IMPORTER_PLUGIN ) . "/fmovies_movie.css?v=3" );

}
add_action( 'admin_enqueue_scripts', 'load_fmovies_movie_style' );

function load_fmovies_discover_style($hook) {
		if($hook != 'toplevel_page_fmovies_discover') {
                return;
        }
        wp_enqueue_style( 'fmovies_discover', esc_url( \IMPORTER_PLUGIN ) . "/fmovies_discover.css" );
}
add_action( 'admin_enqueue_scripts', 'load_fmovies_discover_style' );

function load_fmovies_tv_style($hook) {
		if($hook != 'toplevel_page_fmovies_tv') {
                return;
        }
        wp_enqueue_style( 'fmovies_tv', esc_url( \IMPORTER_PLUGIN ) . "/fmovies_tv.css" );
}
add_action( 'admin_enqueue_scripts', 'load_fmovies_tv_style' );

function load_fmovies_tv_discover_style($hook) {
		if($hook != 'toplevel_page_fmovies_tv_discover') {
                return;
        }
        wp_enqueue_style( 'fmovies_tv_discover', esc_url( \IMPORTER_PLUGIN ) . "/fmovies_tv_discover.css" );
}
add_action( 'admin_enqueue_scripts', 'load_fmovies_tv_discover_style' );

if ( ! function_exists( 'is_post_template' ) ) {
	function is_post_template( $template = '' ) {
		if ( ! is_single() ) {
			return false;
		}

		global $wp_query;

		$post          = $wp_query->get_queried_object();
		$post_template = get_post_meta( $post->ID, 'custom_post_template', true );

		if ( empty( $template ) ) {
			if ( ! empty( $post_template ) ) {
				return true;
			}
		} elseif ( $template == $post_template ) {
			return true;
		}

		return false;
	}
}



add_filter(
	'wp_default_editor',
	function( $default_editor ) {
		if ( current_user_can( 'editor' ) || current_user_can( 'author' ) ) {
			$default_editor = 'html';
		}
		return $default_editor;
	}
);





function fmovie_search_template( $template ) {
	if ( ! have_posts() ) {
		$template = locate_template( array( '404.php' ) );
	}
	return $template;
}
add_filter( 'search_template', 'fmovie_search_template' );


function fmovie_excerpt( $charlength ) {
	$excerpt = get_the_excerpt();
	$charlength++;
	if ( mb_strlen( $excerpt ) > $charlength ) {
		$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
		$exwords = explode( ' ', $subex );
		$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
		if ( $excut < 0 ) {
			echo mb_substr( $subex, 0, $excut );
		} else {
			echo $subex;
		}
		echo '...';
	} else {
		echo $excerpt;
	}
}


add_filter( 'the_content', 'fmovie_the_content', 10, 1 );
function fmovie_the_content( $content = null ) {
	if ( null === $content ) {
			return $content;
	}
	return str_replace( '<p>', '<p>', $content );
}

function fmovie_archive_title( $title ) {
	if ( is_category() ) {
		$title = single_cat_title( '', false );
	} elseif ( is_tag() ) {
		$title = single_tag_title( '', false );
	} elseif ( is_post_type_archive() ) {
		$title = post_type_archive_title( '', false );
	} elseif ( is_tax() ) {
		$title = single_term_title( '', false );
	}

	return $title;
}

add_filter( 'get_the_archive_title', 'fmovie_archive_title' );








function default_og_image( $image ) {
	 global $post;
	if ( is_singular( 'post' ) && ! $image->has_images() ) {
		$image->add_image( 'default' );
	}
}
add_action( 'wpseo_add_opengraph_additional_images', 'default_og_image' );


function default_share_image( $image ) {
	 global $post;
	if ( is_singular( 'post' ) ) {
		if ( ! $image || $image === 'default' ) {

			 $featured_img_url = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			 $poster_path      = get_post_meta( $post->ID, 'poster_path', true );
			 $full_poster_path = 'https://image.tmdb.org/t/p/w600_and_h900_bestv2' . $poster_path;
			 $image            = $full_poster_path;

			if ( $poster_path == '' ) {
				if ( has_post_thumbnail() ) {
					$image = esc_url( $featured_img_url );
				} else {

					$image = esc_url( 'https://via.placeholder.com/600x900?text=No+Poster&000.jpg' );

				}
			} else {

				$image = $full_poster_path;

			}
		}
		return $image;
	}
}
add_action( 'wpseo_twitter_image', 'default_share_image' );
add_action( 'wpseo_opengraph_image', 'default_share_image' );




function post_add_new_columns( $columns ) {
		unset( $columns['author'] );
		unset( $columns['tags'] );
		unset( $columns['comments'] );
		unset( $columns['date'] );
		unset( $columns['wprc_post_reports'] );
		$columns['Year']       = 'Year';
		$columns['categories'] = 'Genre';
		$columns['Poster']     = 'Poster';
		$columns['Type']       = 'Type';
		$columns['Rating']     = 'Rating';
	return $columns;
}
add_filter( 'manage_edit-post_columns', 'post_add_new_columns' );


function post_manage_columns( $column_name, $id ) {
	global $post;
	switch ( $column_name ) {
		case 'Poster':
			$poster_path      = esc_html( get_post_meta( $post->ID, 'poster_path', true ) );
			$poster92         = 'https://image.tmdb.org/t/p/w92' . $poster_path;
			$featured_img_url = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$placeholder      = esc_url( get_template_directory_uri() ) . '/assets/img/placeholder.png';
			if ( has_post_thumbnail() ) {
				echo '<img width="53" height="80" src="' . esc_url( $featured_img_url ) . '" style="border-radius:5px;" />';
			} elseif ( $poster_path == '' ) {
				echo '<img width="53" height="80" src="' . $placeholder . '" style="border-radius:5px;" />';
			} else {
					echo '<img width="53" height="80" src="' . esc_url( $poster92 ) . '" style="border-radius:5px;" />';
			}
			break;
		case 'Type':
			if ( in_category( 'tv-series' ) ) {
				_e( 'TV', 'fmovie' );
			} else {
				_e( 'MOVIE', 'fmovie' ); }
			break;
		case 'Year':
			$years = get_post_meta( $post->ID, 'release_date', true );
			if ( $years == '' ) {
				echo 'Unable to get year';
			} else {
				echo $years;
			}
			break;
		case 'Rating':
			$vote_average = esc_html( get_post_meta( $post->ID, 'vote_average', true ) );
			$vote_average = substr( $vote_average, 0, 3 );
			if ( $vote_average !== '' ) {
				echo '<i style="line-height:-1;color: #f7e330;margin-right:5px;" class="dashicons dashicons-star-filled"></i>' . $vote_average;
			}
			break;
	}
}
add_action( 'manage_post_posts_custom_column', 'post_manage_columns', 10, 2 );

function post_columns_sortable( $columns ) {
	$custom = array(
		'Year'   => 'Year',
		'Rating' => 'Rating',
	);
	return wp_parse_args( $custom, $columns );
}
add_filter( 'manage_edit-post_sortable_columns', 'post_columns_sortable' );

add_action(
	'pre_get_posts',
	function( $query ) {
		if ( ! is_admin() ) {
			return;
		}
		$orderby = $query->get( 'orderby' );
		if ( $orderby == 'Year' ) {
			$query->set( 'meta_key', 'release_date' );
			$query->set( 'orderby', 'meta_value_num' );
		}
		if ( $orderby == 'Rating' ) {
			$query->set( 'meta_key', 'vote_average' );
			$query->set( 'orderby', 'meta_value_num' );
		}
	}
);

add_action( 'admin_bar_menu', 'customize_admin_bar', 999 );
function customize_admin_bar() {
	global $wp_admin_bar;
	if ( ! is_super_admin() || ! is_admin_bar_showing() ) {
		return;
	}

	$wp_admin_bar->add_menu(
		array(
			'id'    => 'wp-admin-bar-fmovie',
			'title' => 'FMovies',
			'href'  => admin_url( 'admin.php?page=admin-main' ),
		)
	);

	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-general',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'General',
			'href'   => admin_url( 'admin.php?page=admin-main' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-home',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Home',
			'href'   => admin_url( 'admin.php?page=admin-home' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-branding',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Branding',
			'href'   => admin_url( 'admin.php?page=admin-branding' ),
		)
	);

	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-translate',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Translate',
			'href'   => admin_url( 'admin.php?page=admin-translate' ),
		)
	);

	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-comments',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Comments',
			'href'   => admin_url( 'admin.php?page=admin-comments' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-player',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Player',
			'href'   => admin_url( 'admin.php?page=admin-player' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-reset',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Reset',
			'href'   => admin_url( 'admin.php?page=admin-reset' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-movie',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Import Movies',
			'href'   => admin_url( 'admin.php?page=fmovies_movie' ),
		)
	);
	$wp_admin_bar->add_menu(
		array(
			'id'     => 'fmovie-tv',
			'parent' => 'wp-admin-bar-fmovie',
			'title'  => 'Import TV',
			'href'   => admin_url( 'admin.php?page=fmovies_tv' ),
		)
	);
}



function fmovies_exclude_pages_from_search_results( $query ) {
	if ( $query->is_main_query() && $query->is_search() && ! is_admin() ) {
		$query->set( 'post_type', array( 'post' ) );
	}
}
add_action( 'pre_get_posts', 'fmovies_exclude_pages_from_search_results' );


function dvk_dequeue_scripts() {

	$load_scripts = false;

	if ( is_singular() ) {
		$post = get_post();

		if ( has_shortcode( $post->post_content, 'contact-form-7' ) ) {
			$load_scripts = true;
		}
	}

	if ( ! $load_scripts ) {
		wp_dequeue_script( 'contact-form-7' );
		wp_dequeue_style( 'contact-form-7' );
	}

}

add_action( 'wp_enqueue_scripts', 'dvk_dequeue_scripts', 99 );