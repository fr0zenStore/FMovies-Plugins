<div class="modal fade" id="login_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered cts-wrapper">
		<div class="modal-content">
			<div class="modal-body">
				<div class="loginajax">
					<form id="lostpasswordform" method="post" style="display:none">
						<button type="button" class="close" data-dismiss="modal"><span>×</span></button>
						<h4><?php _e( 'Forgot password', 'fmovies-login' ); ?></h4>
						<input type="hidden" name="action" value="tg_pwd_reset" />
						<?php wp_nonce_field( 'ajax-pwd-nonce', 'security-pwd' ); ?>     
						<p class="text-gray2"><?php _e( 'We will send an email to your box, just follow that link to set your new password.', 'fmovies-login' ); ?></p>
						<div class="form-group">
							<div id="passstatus"></div>
							<div>
								<label><?php _e( 'Account', 'fmovies-login' ); ?></label>
								<input type="text" name="email" placeholder="<?php _e( 'Your email', 'fmovies-login' ); ?>" class="form-control required email" />
							</div>
						</div>
						<div class="form-group">
							<div>
								<input type="submit" name="submit" class="btn btn-primary btn-lg w-100 submit mt-2" value="<?php _e( 'Reset Password', 'fmovies-login' ); ?>"/>
							</div>
						</div>
						<a class="text-primary float-left mb-2 ajaxback" href="#"><?php _e( 'Back to sign in', 'fmovies-login' ); ?> <i class="bi bi-arrow-right"></i></a>
					</form>
					<form id="signupform" action="" method="post"> 
						<?php if ( function_exists( 'facebooklogin_button' ) ) : ?>
							<?php facebooklogin_button(); ?>
						<p><?php _e( 'or', 'fmovies-login' ); ?></p>
						<?php else : ?>
						<button type="button" class="close" data-dismiss="modal"><span>×</span></button>
						<h4><?php _e( 'Account Sign Up', 'fmovies-login' ); ?></h4>
						<?php endif ?>
						<div class="form-group">
							<div id="signupstatus"></div>
							<div>
								<label><?php _e( 'Username*', 'fmovies-login' ); ?></label>
								<input type="text" name="username" placeholder="<?php _e( 'Username', 'fmovies-login' ); ?>" class="username form-control required alphanumeric" required>
							</div>
						</div>
						<div class="form-group">
							<div >
								<label><?php _e( 'Email*', 'fmovies-login' ); ?></label>
								<input type="text" name="email" placeholder="<?php _e( 'Email', 'fmovies-login' ); ?>" class="form-control required email " required>
							</div>
						</div>
						<div class="form-group">
							<div>
								<label><?php _e( 'Password*', 'fmovies-login' ); ?></label>
								<input type="password" name="password" placeholder="<?php _e( 'Password', 'fmovies-login' ); ?>" id="password" class="password form-control required" required>
							</div>
						</div>
						<div class="form-group">
							<div>
								<label><?php _e( 'Repeat password*', 'fmovies-login' ); ?></label>
								<input type="password" name="password2" placeholder="<?php _e( 'Repeat password', 'fmovies-login' ); ?>" id="password2" class="form-control required" required>
							</div>
						</div>
						<?php wp_nonce_field( 'ajax-signup-nonce', 'security-signup' ); ?>
						<div class="form-group">
							<div>
								<input type="submit" name="submit" class="btn btn-primary btn-lg w-100 submit mt-2" value="<?php _e( 'Sign up', 'fmovies-login' ); ?>"/>
							</div>
						</div>
						<span><?php _e( 'Already have account?', 'fmovies-login' ); ?> <a class="text-primary cts-switcher ajaxsignin" href="#"><?php _e( 'Sign In', 'fmovies-login' ); ?></a></span>
					</form>
					<form id="loginform"  method="post" style="display:none">
						<?php if ( function_exists( 'facebooklogin_button' ) ) : ?>
							<?php // facebooklogin_button() ?>
						<p><?php _e( 'or', 'fmovies-login' ); ?></p>
						<?php else : ?>
						<button type="button" class="close" data-dismiss="modal"><span>×</span></button>
						<h4><?php _e( 'Welcome back!', 'fmovies-login' ); ?></h4>
						<?php endif ?>
						<div class="form-group">
							<div class="loginstatus"></div>
							<div >
								<label><?php _e( 'Account', 'fmovies-login' ); ?></label>
								<input type="text" name="username" id="username" placeholder="<?php _e( 'Username or email', 'fmovies-login' ); ?>" class="form-control" required>
							</div>
						</div>
						<div class="form-group">
							<div>
								<label><?php _e( 'Password', 'fmovies-login' ); ?></label>
								<input type="password" name="password" id="password3" placeholder="<?php _e( 'Your password', 'fmovies-login' ); ?>" class="form-control" required>
							</div>
						</div>
						<div class="form-group">
							<div>
								<input class="btn btn-primary btn-lg w-100 submit mt-2" type="submit" value="<?php _e( 'Sign in', 'fmovies-login' ); ?>" name="submit">
							</div>
						</div>
						<?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
						<div>
							<a class="text-primary float-left mb-2 pb-1 ajaxlostpassword" href="#"><?php _e( 'Forgot your password', 'fmovies-login' ); ?> <i class="bi bi-arrow-right"></i></a> 
							<a class="text-primary float-left mb-2 ajaxsignup" href="#"><?php _e( 'Sign up for a new account', 'fmovies-login' ); ?> <i class="bi bi-arrow-right"></i></a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div> 
