<?php
/**
Plugin Name: FMovies Login
Plugin URI: https://fr0zen.store/
Description: Bootstrap modal login plugin
Author: fr0zen
Version: 0.1
Author URI: https://fr0zen.store
 */
function fmovies_ajax_login() {
	check_ajax_referer( 'fmovies_login_nonce', 'nonce' );
	$info                  = array();
	$info['user_login']    = $_POST['username'];
	$info['user_password'] = $_POST['password'];
	$info['remember']      = true;

	$user_signon = wp_signon( $info, false );
	if ( is_wp_error( $user_signon ) ) {
		echo json_encode(
			array(
				'loggedin' => false,
				'message'  => 'error',
			)
		);
	} else {
		wp_set_current_user( $user_signon->ID );
		wp_set_current_user( $user_signon->ID );
		wp_set_auth_cookie( $user_signon->ID );
		echo json_encode(
			array(
				'loggedin' => true,
				'message'  => 'success',
			)
		);
	}
	die();
}

function fmovies_ajax_checkusername(): never {
	die( username_exists( $_GET['username'] ) ? json_encode( false ) : json_encode( true ) );
}

function fmovies_ajax_checkemail(): never {
	die( email_exists( $_GET['email'] ) ? json_encode( false ) : json_encode( true ) );
}


function fmovies_ajax_register() {
	check_ajax_referer( 'ajax-signup-nonce', 'security-signup' );

	$userdata = array(
		'user_pass'  => $_POST['password'],
		'user_email' => $_POST['email'],
		'user_login' => $_POST['username'],
	);
	$user_id  = wp_insert_user( $userdata );
	if ( ! is_wp_error( $user_id ) ) {
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id );
		echo json_encode(
			array(
				'register' => true,
				'message'  => 'success',
				'info'     => __(
					'Signup successful',
					'fmovies-login'
				),
			)
		);
	} else {
		$errors = array(
			'existing_user_login' => __( 'This username is taken', 'fmovies-login' ),
			'existing_user_email' => __( 'This email is already registered', 'fmovies-login' ),
		);
		echo json_encode(
			array(
				'register' => false,
				'message'  => 'error',
				'info'     => $errors[ $user_id->get_error_code() ],
			)
		);
	}
	die();
}



function fmovies_ajax_lostpassword() {
	global $wpdb;
	check_ajax_referer( 'ajax-pwd-nonce', 'security-pwd' );
	if ( empty( $_POST['email'] ) ) {
		die( "<div class='alert alert-danger'>" . __( 'Please enter your Username or E-mail address', 'fmovies-login' ) . '</div>' );
	}
	$user_input = trim( (string) $_POST['email'] );
	if ( strpos( $user_input, '@' ) ) {
		$user_data = get_user_by_email( $user_input );
		if ( empty( $user_data ) || $user_data->caps[ \ADMINISTRATOR ] == 1 ) {
			// delete the condition $user_data->caps[administrator] == 1, if you want to allow password reset for admins also
			die( "<div class='alert alert-danger'>" . __( 'Invalid E-mail address', 'fmovies-login' ) . '</div>' );
		}
	} else {
		$user_data = get_userdatabylogin( $user_input );
		if ( empty( $user_data ) || $user_data->caps[ \ADMINISTRATOR ] == 1 ) {
			// delete the condition $user_data->caps[administrator] == 1, if you want to allow password reset for admins also
			die( "<div class='alert alert-danger'>" . __( 'Invalid Username', 'fmovies-login' ) . '</div>' );
		}
	}
	$user_login = $user_data->user_login;
	$user_email = $user_data->user_email;

	$key = $wpdb->get_var( $wpdb->prepare( "SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login ) );
	if ( empty( $key ) ) {
		$key = wp_generate_password( 20, false );
		$wpdb->update( $wpdb->users, array( 'user_activation_key' => $key ), array( 'user_login' => $user_login ) );
	}

	$message  = __( 'Someone requested that the password be reset for the following account:' ) . "\r\n\r\n";
	$message .= home_url() . "\r\n\r\n";
	$message .= sprintf( __( 'Username: %s' ), $user_login ) . "\r\n\r\n";
	$message .= __( 'If this was a mistake, just ignore this email and nothing will happen.' ) . "\r\n\r\n";
	$message .= __( 'To reset your password, visit the following address:' ) . "\r\n\r\n";
	if ( $_POST['lang'] ) {
		$langrequest = '&lang=' . $_POST['lang'];
	}
	$resetlink = get_option( 'siteurl' ) . '?resetpassword&key=' . rawurlencode( (string) $key ) . '&login=' . $user_login . $langrequest . "\r\n\r\n";
	$message   = apply_filters( 'fmovies_login_reset_pwd_email_message', $message . $resetlink, $resetlink, $user_email );
	do_action(
		'fmovies_login_reset_pwd_email',
		array(
			'message' => $message,
			'email'   => $user_email,
			'link'    => $resetlink,
		)
	);

	if ( $message && ! wp_mail( $user_email, __( 'Password Reset Request', 'fmovies-login' ), $message, array( 'Content-Type: text/plain; charset=UTF-8' ) ) ) {
		die( "<div class='alert alert-danger'>" . __( 'Email failed to send for some unknown reason.', 'fmovies-login' ) . '</div>' );
	} else {
		die( "<div class='alert alert-success'>" . __( 'We have just sent you an email with Password reset instructions.', 'fmovies-login' ) . '</div>' );
	}
}

add_action( 'after_setup_theme', 'fmovies_login_remove_admin_bar' );

function fmovies_login_remove_admin_bar() {
	if ( ! current_user_can( 'administrator' ) && ! is_admin() ) {
		show_admin_bar( false );
	}
}

function fmovies_login_init() {
	if ( ! is_user_logged_in() ) {
		add_action( 'wp_ajax_nopriv_ajaxlogin', 'fmovies_ajax_login' );
		add_action( 'wp_ajax_nopriv_ajaxregister', 'fmovies_ajax_register' );
		add_action( 'wp_ajax_nopriv_ajaxlostpassword', 'fmovies_ajax_lostpassword' );
		add_action( 'wp_ajax_nopriv_ajax_checkusername', 'fmovies_ajax_checkusername' );
		add_action( 'wp_ajax_nopriv_ajax_checkemail', 'fmovies_ajax_checkemail' );
		add_action( 'wp_footer', 'fmovies_login_modal', 10 );
	}
}
add_action( 'init', 'fmovies_login_init' );



function fmovies_login_modal() {
	if ( file_exists( trailingslashit( get_stylesheet_directory() ) . 'fmovies-login-template.php' ) ) {
		include trailingslashit( get_stylesheet_directory() ) . 'fmovies-login-template.php';
	} else {
		include __DIR__ . '/fmovies-login-template.php';
	}
}


function fmovies_save_profile( $user_id ) {
	$usermetas = array(
		'first_name' => $_POST['first_name'],
		'last_name'  => $_POST['last_name'],
		'city'       => $_POST['city'],
		'country'    => $_POST['country'],
		'postalcode' => $_POST['postalcode'],
		'address'    => $_POST['address'],
		'newsletter' => $_POST['newsletter'],
		'children'   => $_POST['children'],
		'usertitle'  => $_POST['usertitle'],
	);
	if ( $_POST['date_year'] > '1900' ) {
		$usermetas['dob'] = $_POST['date_month'] . '/' . $_POST['date_day'] . '/' . $_POST['date_year'];
	}
	foreach ( $usermetas as $key => $value ) {
		update_user_meta( $user_id, $key, $value );
	}
}


function fmovies_get_user_profile( $user_id ) {
	$usermetas = array( 'first_name', 'last_name', 'city', 'country', 'postalcode', 'address', 'newsletter', 'children', 'usertitle', 'dob' );
	$profile   = array();
	foreach ( $usermetas as $key ) {
		$profile[ $key ] = get_user_meta( $user_id, $key, true );
	}
	return $profile;
}




function fmovies_reset_password() {
	global $wpdb, $user_ID;
	$reset_key  = $_GET['key'];
	$user_login = $_GET['login'];
	$user_data  = $wpdb->get_row( $wpdb->prepare( "SELECT ID, user_login, user_email FROM $wpdb->users WHERE user_activation_key = %s AND user_login = %s", $reset_key, $user_login ) );

	$user_login = $user_data->user_login;
	$user_email = $user_data->user_email;

	if ( ! empty( $reset_key ) && ! empty( $user_data ) ) {
		$new_password = wp_generate_password( 7, false );
		// echo $new_password; exit();
		wp_set_password( $new_password, $user_data->ID );
		// mailing reset details to the user
		$message  = __( 'Your new password for the account at:' ) . "\r\n\r\n";
		$message .= get_option( 'siteurl' ) . "\r\n\r\n";
		$message .= sprintf( __( 'Username: %s' ), $user_login ) . "\r\n\r\n";
		$message .= sprintf( __( 'Password: %s' ), $new_password ) . "\r\n\r\n";
		$message .= __( 'You can now login with your new password at: ' ) . get_option( 'siteurl' ) . '/login' . "\r\n\r\n";

		if ( $message && ! wp_mail( $user_email, __( 'Password Reset Request', 'fmovies-login' ), $message, array( 'Content-Type: text/plain; charset=UTF-8' ) ) ) {
			return "<div class='alert alert-danger'>" . __( 'Email failed to send for some unknown reason.', 'fmovies-login' ) . '</div>';
		} else {
			return "<div class='alert alert-success'>" . __( 'A new password has been sent to your email address', 'fmovies-login' ) . '</div>';
		}
	} else {
		exit( 'Not a Valid Key.' );
	}
}



function fmovies_reset_pwd_form() {
	global $wpdb, $user_ID;
	$reset_key  = $_GET['key'];
	$user_login = $_GET['login'];
	$user_data  = $wpdb->get_row( $wpdb->prepare( "SELECT ID, user_login, user_email FROM $wpdb->users WHERE user_activation_key = %s AND user_login = %s", $reset_key, $user_login ) );

	if ( ! empty( $reset_key ) && ! empty( $user_data ) ) {
		if ( $_POST['password'] && strlen( (string) $_POST['password'] ) >= 4 ) {
			wp_set_password( $_POST['password'], $user_data->ID );
			?>
		  <div class="alert alert-success"><?php _e( 'Your password has been updated', 'fmovies-login' ); ?></div>
			<?php
		} else {
			?>
		<h4><?php _e( 'Password Reset Request', 'fmovies-login' ); ?></h4>
		<form class="form-horizontal"  role="form" id="pwdform" method="POST" action="">
		<div class="form-group">
		<label class="col-sm-6 control-label" for="password"><?php _e( 'Password', 'fmovies-login' ); ?></label>
		<div class="col-sm-6">
		<input type="password" name="password" id="password" class="form-control required" />
		</div>
		</div>
		<div class="form-group">
		<label class="col-sm-6 control-label" for="password2"><?php _e( 'Repeat password', 'fmovies-login' ); ?></label>
		<div class="col-sm-6">
		<input type="password" name="password2" id="password2" class="form-control required" />
		</div>
		</div>
		  <div class="form-group">
			  <div class="col-sm-offset-6 col-sm-6">
				<input type="submit" name="submit" class="btn btn-primary" value="<?php _e( 'Update password', 'fmovies-login' ); ?>"/>
			  </div>
			</div>
		  </form>
	<script>

	  jQuery(document).ready(function($){
		 $( "#pwdform" ).validate({
		   errorClass: "text-danger small",
		   highlight: function(element) {
			   $(element).closest('.form-group').addClass('has-error');
		   },
		   unhighlight: function(element) {
			   $(element).closest('.form-group').removeClass('has-error');
		   },
		   errorPlacement: function(error, element) {
			   element.closest('div').append(error);
		   },


			rules: {
			  password: {
				required: true,
				minlength: 5
			  },
			  password2: {
				equalTo: "#pwdform #password"
			  }
			}
		  });

	  })
	  jQuery.extend(jQuery.validator.messages, {
			required: "<?php _e( 'This field is mandatory', 'fmovies-login' ); ?>",
			email: "<?php _e( 'Please check this email address', 'fmovies-login' ); ?>",
			equalTo:"<?php _e( 'Please enter the same value again.', 'fmovies-login' ); ?>",
			minlength: jQuery.format("<?php _e( 'Enter at least {0} characters', 'fmovies-login' ); ?>")

	   });
	</script>

			<?php
		}
	} else {
		_e( 'Not a Valid Key.', 'fmovies-login' );
	}
}


add_filter( 'template_include', 'fmovies_reset_password_template', 1, 1 );
function fmovies_reset_password_template( $template ) {
	if ( isset( $_GET['resetpassword'] ) ) {
		return __DIR__ . '/fmovies_login_resetpassword.php';
	}
	return $template;
}

function fmovies_change_pwd_form() {
	$user = wp_get_current_user();
	if ( $user ) {
		if ( $_POST['password'] && strlen( (string) $_POST['password'] ) > 4 ) {
			if ( wp_check_password( $_POST['oldpassword'], $user->data->user_pass, $user->ID ) ) {
				wp_set_password( $_POST['password'], $user->ID );
				?>
		  <div class="alert alert-success"><?php _e( 'Your password has been changed', 'fmovies-login' ); ?></div>
				<?php
			} else {
				?>
		  <div class="alert alert-danger"><?php _e( 'Wrong password', 'fmovies-login' ); ?></div>
				<?php
				$passerror = true;
			}
		}

		if ( $passerror || ! isset( $_POST['password'] ) ) {
			?>
	<h1></h1>
		<form class="form-horizontal"  role="form" id="pwdform" method="POST" action="?savepass">
		<div class="form-group">
		<label class="col-sm-6 control-label" for="oldpassword"><?php _e( 'Old password', 'fmovies-login' ); ?></label>
		<div class="col-sm-6">
		<input type="oldpassword" name="oldpassword" id="oldpassword" class="form-control required" />
		</div>
		</div>
		<div class="form-group">
		<label class="col-sm-6 control-label" for="password"><?php _e( 'Password', 'fmovies-login' ); ?></label>
		<div class="col-sm-6">
		<input type="password" name="password" id="password" class="form-control required" />
		</div>
		</div>
		<div class="form-group">
		<label class="col-sm-6 control-label" for="password2"><?php _e( 'Repeat password', 'fmovies-login' ); ?></label>
		<div class="col-sm-6">
		<input type="password" name="password2" id="password2" class="form-control required" />
		</div>
		</div>
		  <div class="form-group">
			  <div class="col-sm-offset-6 col-sm-6">
				<input type="submit" name="submit" class="btn btn-primary" value="<?php _e( 'Update password', 'fmovies-login' ); ?>"/>
			  </div>
			</div>
		  </form>
	<script>

	  jQuery(document).ready(function($){
		 $( "#pwdform" ).validate({
			rules: {
			  oldpass:{required: true},
			  password: {
				required: true,
				minlength: 5
			  },
			  password2: {
				equalTo: "#pwdform #password"
			  }
			}
		  });

	  })
	  jQuery.extend(jQuery.validator.messages, {
			required: "<?php _e( 'This field is mandatory', 'fmovies-login' ); ?>",
			email: "<?php _e( 'Please check this email address', 'fmovies-login' ); ?>",
			equalTo:"<?php _e( 'Please enter the same value again.', 'fmovies-login' ); ?>",
			minlength: jQuery.format("<?php _e( 'Enter at least {0} characters', 'fmovies-login' ); ?>")

	   });
	</script>

			<?php
		}
	}
}


function fmovies_change_passwordform_shortcode( $atts, $content = null ) {
	ob_start();
	fmovies_change_pwd_form();
	return ob_get_clean();
}

add_shortcode( 'changepasswordform', 'fmovies_change_passwordform_shortcode' );



function fmovies_passwordform_shortcode( $atts, $content = null ) {
	ob_start();
	fmovies_reset_pwd_form();
	return ob_get_clean();
}

add_shortcode( 'passwordform', 'fmovies_passwordform_shortcode' );



function fmovies_usermenu_shortcode( $atts, $content = null ) {
	$tag = isset( $atts['tag'] ) && $atts['tag'] == 'li' ? 'li' : 'div';
	ob_start();
	?>
	  <?php
		if ( is_user_logged_in() ) :
			global $current_user;
			get_currentuserinfo();
			$fb = get_user_meta( $current_user->ID, 'fbid', true );

			?>
		<<?php echo $tag; ?> class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
			<?php
			if ( $fb ) {
				echo '<img src="https://graph.facebook.com/' . $fb . '/picture" width="15" height="15" alt="icon" class="fbimage"/> ';
			}
			?>
			<?php echo __( 'Hi', 'fmovies-login' ) . ' ' . $current_user->display_name; ?>
		<span class="caret"></span></a>
		<ul class="dropdown-menu" role="menu" >
		<li><a href="<?php echo wp_logout_url( fmovies_login_full_path() ); ?>"><i class="glyphicon glyphicon-log-out"></i> <?php _e( 'Sign out', 'fmovies-login' ); ?></a></li>
		</ul>
		</<?php echo $tag; ?>>
		<?php else : ?>
		<<?php echo $tag; ?> class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-log-in "></i> <?php _e( 'Sign in', 'fmovies-login' ); ?> <span class="caret"></span></a>
		<ul class="dropdown-menu" role="menu" >
		<li><a href="#" class="ajaxlogin"><?php _e( 'Log in', 'fmovies-login' ); ?></a></li>
		<li><a href="#" class="ajaxsignup"><?php _e( 'Register', 'fmovies-login' ); ?></a></li>
		</ul>
		</<?php echo $tag; ?>>
	  <?php endif; ?>
	<?php
	return ob_get_clean();
}

add_shortcode( 'usermenu', 'fmovies_usermenu_shortcode' );

add_filter( 'widget_text', 'do_shortcode' );


function fmovies_check_user_role( $role, $user_id = null ) {
	$user = is_numeric( $user_id ) ? get_userdata( $user_id ) : wp_get_current_user();
	if ( empty( $user ) ) {
		return false;
	}
	return in_array( strtolower( (string) $role ), $user->roles );
}


function fmovies_useraccess_shortcode( $atts, $content = null ) {
	if ( is_user_logged_in() ) {
		global $current_user;
		$data = array( 'user_nicename', 'user_email', 'user_login' );
		get_currentuserinfo();
		foreach ( $data as $key ) {
			$content = str_replace( '{{' . $key . '}}', $current_user->data->{$key}, $content );
		}
		$content = str_replace( '{{logouturl}}', wp_logout_url( fmovies_login_full_path() ), $content );
	}

	$content = do_shortcode( $content );

	if ( ! isset( $atts['grant'] ) || $atts['grant'] == 'subscriber' ) {
		return is_user_logged_in() ? $content : '';
	} elseif ( $atts['grant'] == 'loggedoff' && ! is_user_logged_in() ) {
		return $content;
	} elseif ( fmovies_check_user_role( $atts['grant'] ) ) {
		return $content;
	}
}


add_shortcode( 'useraccess', 'fmovies_useraccess_shortcode' );


function fmovies_forget_password_form() {
	if ( $_REQUEST['action'] == 'tg_pwd
      _reset' ) {
		$msg = fmovies_ask_password_reset();
		die( $msg );
	}
	if ( isset( $_GET['key'] ) && $_GET['action'] == 'reset_pwd' ) {
		echo fmovies_reset_password();
	} else {
		?>
		<?php
	}
}



function fmovies_login_signup_vars() {

	$vars = array(
		'validate_required'     => __( 'This field is required', 'fmovies-login' ),
		'validate_email'        => __( 'Please enter a valid email address', 'fmovies-login' ),
		'validate_equalTo'      => __( 'Please enter the same value again.', 'fmovies-login' ),
		'validate_minlength'    => __( 'Enter at least {0} characters', 'fmovies-login' ),
		'validate_alphanumeric' => __( 'Enter at least {0} characters', 'fmovies-login' ),
		'checking_email'        => __( 'Checking email address', 'fmovies-login' ),
		'sending_info'          => __( 'Sending user info, please wait...', 'fmovies-login' ),
		'login_successfull'     => __( 'Login successful, redirecting...', 'fmovies-login' ),
		'login_error'           => __( 'Wrong username or password.', 'fmovies-login' ),
		'validate_username'     => __( 'This username is already taken.', 'fmovies-login' ),
		'ajaxurl'               => admin_url( 'admin-ajax.php' ),
		'login_nonce'           => wp_create_nonce( 'fmovies_login_nonce' ),
	);

	if ( function_exists( 'pll_current_language' ) ) {
		$vars['lang'] = pll_current_language();
	}
	return $vars;
}

function fmovies_login_scripts() {
	if ( ! is_front_page() ) {
		wp_enqueue_script( 'jquery.validate', plugins_url( 'js/jquery.validate.min.js', __FILE__ ), array( 'jquery' ), wp_get_theme()->get( 'Version' ), true );
		wp_register_script( 'ajaxlogin', plugins_url( 'fmovies-login.js', __FILE__ ), array( 'jquery' ), strtotime( 'now' ), true );
		wp_enqueue_script( 'jquery.validate.additional', plugins_url( 'js/additional-methods.min.js', __FILE__ ), array( 'jquery' ), wp_get_theme()->get( 'Version' ), true );
		wp_localize_script( 'ajaxlogin', 'ajaxlogin', fmovies_login_signup_vars() );
		wp_enqueue_script( 'ajaxlogin' );
	}
}


add_action( 'wp_enqueue_scripts', 'fmovies_login_scripts' );

function fmovies_login_styles() {
	// wp_enqueue_style( 'fmovies-login', plugins_url( 'fmovies-login.css' , __FILE__ ));
}

add_action( 'wp_print_styles', 'fmovies_login_styles', 100 );


function fmovies_login_full_path() {
	$s        = &$_SERVER;
	$ssl      = ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on';
	$sp       = strtolower( (string) $s['SERVER_PROTOCOL'] );
	$protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
	$port     = $s['SERVER_PORT'];
	$port     = ( ( ! $ssl && $port == '80' ) || ( $ssl && $port == '443' ) ) ? '' : ':' . $port;
	$host     = $s['HTTP_X_FORWARDED_HOST'] ?? $s['HTTP_HOST'] ?? null;
	$host   ??= $s['SERVER_NAME'] . $port;
	$uri      = $protocol . '://' . $host . $s['REQUEST_URI'];
	$segments = explode( '?', $uri, 2 );
	return $segments[0];
}



function fmovies_login_load_textdomain() {
	load_plugin_textdomain( 'fmovies-login', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'init', 'fmovies_login_load_textdomain' );


add_action( 'admin_menu', 'fmovies_login_menu_init' );

function fmovies_login_menu_init() {
	add_options_page( 'fmovies Login settinge', 'fmovies Login', 'manage_options', 'fmovies_login_menu_settings', 'fmovies_login_menu_settings' );
}

function fmovies_login_menu_settings() {
	?>
<div class="wrap">
<div id="icon-tools" class="icon32"><br></div><?php echo '<h2>' . __( 'fmovies Login settings' ) . '</h2>'; ?>
<form  method="post">
	<?php
	if ( $_POST !== array() ) {
		update_option( 'fmovies-email-confirmation', $_POST['emailconfirmation'] );
		echo 'settings saved';
	}
	?>
<table class="form-table">
<tr>
<th scope="row"><label for="emailconfirmation">Email confirmation</label></th>
<td><input name="emailconfirmation" type="checkbox" id="emailconfirmation" value="1" <?php echo get_option( 'fmovies-email-confirmation' ) ? ' checked ' : ''; ?> /></td>
</tr>
</table>
<p class="submit">
<input class="button button-primary" type="submit" name="Submit" value="<?php _e( 'Save Changes' ); ?>" />
</p>
</form>
</div> <!-- end wrap -->
	<?php
}

?>
