<?php


namespace App;

use App\Traits\Boot;
use App\Traits\Menu;
use App\Traits\Tools;
use App\Traits\Tv;
use TMDB\Tmdb;


class Bootstrap extends Tmdb {

	use Menu;
	use Boot;
	use Tv;
	use Tools;

	public function __construct( $api_key = '7ac6de5ca5060c7504e05da7b218a30c' ) {
		parent::__construct( $api_key );
		$this->isMovieWP();
		add_action( 'admin_menu', array( $this, 'CreateAdminMenu' ) );
		$wp_ajax_action = 'wp_ajax_' . $_POST['action'];
		if ( isset( $_POST['action'] ) && $_POST['action'] == 'SearchMovie' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Discover' ) {

			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Populars' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Rated' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Upcoming' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Playing' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Trending' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Animation' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'AddMovie' ) {
			add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
        } elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'SearchSerie' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Discovering' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Popular' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
        } elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Top' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Air' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'Anime' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'AddSerie' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
		} elseif ( isset( $_POST['action'] ) && $_POST['action'] == 'SearchSerie' ) {
		add_action( $wp_ajax_action, array( $this, $_POST['action'] ) );
	    }
}
	private function isMovieWP(): void {
		if ( wp_get_theme() != 'fmovie' ) {
			add_action(
				'admin_menu',
				function () {
					if ( is_plugin_active( \IMPORTER ) ) {
						deactivate_plugins( \IMPORTER );
					}
				}
			);

		}
	}

	public function load_page(): void {

		wp_enqueue_script(
			'fmovies_jquery',
			'//code.jquery.com/jquery-3.5.1.min.js'
		);
		wp_enqueue_script(
			'fmovies_popper',
			'//cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'
		);
		wp_enqueue_script(
			'fmovies_bootstrap',
			'//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'
		);
		wp_enqueue_script(
			'fmovies_mdb',
			'//cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js'
		);
		wp_enqueue_style(
			'fmovies_font',
			'//use.fontawesome.com/releases/v5.8.2/css/all.css'
		);
		wp_enqueue_style(
			'fmovies_bootstrap',
			'//stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'
		);
		wp_enqueue_style(
			'fmovies_mdb',
			'//cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css'
		);

		if ( $_GET['page'] == 'fmovies_tv' ) {

			wp_enqueue_script( 'fmovies_tv', plugin_dir_url( __DIR__ ) . 'App/public/js/fmovies_tv.js', array( 'jquery' ), strtotime( 'now' ) );
			wp_localize_script( 'fmovies_tv', 'fmovies_ajax', array( 'url' => admin_url( 'admin-ajax.php' ) ) );

		}
		if ( $_GET['page'] == 'fmovies_tv_discover' ) {

			wp_enqueue_script( 'fmovies_tv_discover', plugin_dir_url( __DIR__ ) . 'App/public/js/fmovies_tv_discover.js', array( 'jquery' ), strtotime( 'now' ) );
			wp_localize_script( 'fmovies_tv_discover', 'fmovies_ajax', array( 'url' => admin_url( 'admin-ajax.php' ) ) );
		}
		if ( $_GET['page'] == 'fmovies_discover' ) {

			wp_enqueue_script( 'fmovies_discover', plugin_dir_url( __DIR__ ) . 'App/public/js/fmovies_discover.js', array( 'jquery' ), strtotime( 'now' ) );
			wp_localize_script( 'fmovies_discover', 'fmovies_ajax', array( 'url' => admin_url( 'admin-ajax.php' ) ) );
		}
		if ( $_GET['page'] == 'fmovies_movie' ) {

			wp_enqueue_script( 'fmovies_movie', plugin_dir_url( __DIR__ ) . 'App/public/js/fmovies_movie.js', array( 'jquery' ), strtotime( 'now' ) );
			wp_localize_script( 'fmovies_movie', 'fmovies_ajax', array( 'url' => admin_url( 'admin-ajax.php' ) ) );
		}

		if ( file_exists( PLUGIN_DIR . '/App/public/' . $_GET['page'] . '.php' ) ) {
			include PLUGIN_DIR . '/App/public/' . $_GET['page'] . '.php';
		} else {
			include PLUGIN_DIR . '/App/public/404.php';
		}
	}

}
