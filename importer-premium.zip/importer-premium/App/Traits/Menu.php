<?php

namespace App\Traits;

trait Menu {
	public function CreateAdminMenu(): void {
		add_menu_page(
			'Movies',
			'Movies',
			'manage_options',
			'fmovies_movie',
			array( $this, 'load_page' ),
			'dashicons-editor-video',
			62
		);
		add_menu_page(
			'Discover',
			'Discover',
			'manage_options',
			'fmovies_discover',
			array( $this, 'load_page' ),
			'dashicons-code-standards',
			62
		);
		add_menu_page(
			'TV',
			'TV',
			'manage_options',
			'fmovies_tv',
			array( $this, 'load_page' ),
			'dashicons-desktop',
			62
		);
		add_menu_page(
			'TV Discover',
			'TV Discover',
			'manage_options',
			'fmovies_tv_discover',
			array( $this, 'load_page' ),
			'dashicons-desktop',
			62
		);

	}
}
