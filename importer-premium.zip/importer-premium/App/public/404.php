<div class="wrap" style="text-align: center;">
	<img src="<?php echo plugin_dir_url( __FILE__ ); ?>/404_Image.png" alt="404 Page"
		 style="margin-top: 2em; max-width: 100%;">
</div>
