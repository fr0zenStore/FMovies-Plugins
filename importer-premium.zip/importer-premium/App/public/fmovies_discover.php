<?php $randomDate = random_int( 2000, 2025 ); ?>
<div class="wrap">
	<h1 class="wp-heading-inline">Movie Importer <span>(Discover)</span></h1>
	<span class="api"><i class="fa fa-circle flashit"></i>&nbsp;&nbsp;API is online</span>
	<hr class="wp-header-end">
	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a class="nav-link" href="admin.php?page=fmovies_movie">Search</a>
				</li>
				<li class="nav-item">
					<a id="discover" class="nav-link active" href="admin.php?page=fmovies_discover">Discover</a>
				</li>
			</ul>
			<div id="postbox-container-1" class="postbox-container">
				<div id="side-sortables" class="meta-box-sortables ui-sortable ui-sortable-disabled">
					<div id="submitdiv" class="postbox">
						<h2><span class="type">Movie Discover</span></h2>
						<div class="inside">
							<form data-view="tmdb_result" data-callback="show_tmdb_search" data-method="post"
								  id="tmdb_search" class="fmovies_form">
								<div class="submitbox" id="submitpost">
									<div id="minor-publishing">
										<div id="minor-publishing-actions" style="text-align: left">
											<input type="hidden" name="page" id="page" value="1">
											<input type="hidden" value="Discover" name="action">
											<label style="display:none;" class="mtt">Language</label>
											<select style="display:none;" name="language" id="language"
													style="width: 100%">
												<option value="<?php echo \APILANGUAGE; ?>" selected>Default</option>
											</select>
											<div class="def-number-input number-input safari_only" style="width: 100%">
												<button onclick="this.parentNode.querySelector('input[type=number]').stepDown()"
														class="minus"></button>
												<input class="quantity" id="primary_release_year" min="1900" max="2023"
													   name="primary_release_year" value="<?php echo $randomDate; ?>"
													   type="number">
												<button onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
														class="plus"></button>
											</div>
											<p></p>
											<p><select name="sort_by" id="sort_by" style="width: 100%">
													<option value="popularity.desc" selected>Popularity desc</option>
													<option value="popularity.asc">Popularity asc</option>
													<option value="revenue.desc">Revenue desc</option>
													<option value="revenue.asc">Revenue asc</option>
													<option value="release_date.desc">Release date desc</option>
													<option value="release_date.asc">Release date asc</option>
													<option value="vote_average.desc">Vote average desc</option>
													<option value="vote_average.asc">Vote average asc</option>
													<option value="vote_count.desc">Vote count desc</option>
													<option value="vote_count.asc">Vote count asc</option>

											</p>
											</select>
											<p><select id="with_genres" name="with_genres" style="width: 100%">
													<option value="">All genres</option>
													<option value="28">Action</option>
													<option value="12">Adventure</option>
													<option value="16">Animation</option>
													<option value="35">Comedy</option>
													<option value="80">Crime</option>
													<option value="99">Documentary</option>
													<option value="18">Drama</option>
													<option value="10751">Family</option>
													<option value="14">Fantasy</option>
													<option value="36">History</option>
													<option value="27">Horror</option>
													<option value="10402">Music</option>
													<option value="9648">Mystery</option>
													<option value="10749">Romance</option>
													<option value="878">Science Fiction</option>
													<option value="10770">TV Movie</option>
													<option value="53">Thriller</option>
													<option value="10752">War</option>
													<option value="37">Western</option>
											</p>
											</select>
										</div>
										<div class="clear"></div>
									</div>
									<div id="major-publishing-actions">
										<button style="float:left;border:none!important;" type="button" id="reset"
												name="reset" class="button button-reset button-large btn btn-danger"><i
													class="fas fa-undo"></i></button>
										<div id="publishing-action">
											<span class="spinner"></span>
											<button type="button" id="publish"
													class="button button-cancel button-large btn btn-primary"
													style="display: none;">New Search
											</button>
											<button type="submit" id="publish"
													class="button button-primary button-large btn btn-primary">Search
											</button>
										</div>
										<div class="clear"></div>
									</div>
								</div>
							</form>
							<form data-callback="show_movie_add" data-method="post" id="tmdb_movie_add"
								  class="fmovies_form" data-view="tmdb_api">
								<input type="hidden" value="AddMovie" name="action" required>
								<input type="hidden" value="" id="tmdb_movie_id" name="tmdb_movie_id" required>
								<input type="hidden" name="tmdb_language" id="tmdb_language" value="en-US">
								<div class="tmdb_api" style="align-t"></div>
							</form>
						</div>
					</div>
				</div>
				<p class="hide-if-no-js">
					<button type="button" class="button-link" id="bulk-import" aria-expanded="false"
							style="display: none;">Bulk import
					</button>
				</p>
				<div id="tags"></div>
			</div>
			<div class="postbox-container" id="post-body">
				<div id="submitdiv" class="postbox results">
					<h2 style="text-align: center"><span>Results: <span class="result_page"></span></span>
						<p class="total"></p></h2>
					<div class="inside">
						<div class="submitbox" id="submitpost">
							<div id="minor-publishing" class="tmdb_result" style="padding: 15px;">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>var randomYear = "<?php echo $randomDate; ?>";</script>
