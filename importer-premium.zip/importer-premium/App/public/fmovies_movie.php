<div class="wrap">
	<h1 class="wp-heading-inline">Movie Importer <span>(Search)</span></h1>
	<span class="api"><i class="fa fa-circle flashit"></i>&nbsp;&nbsp;API is online</span>
	<hr class="wp-header-end">
	<div id="poststuff">
		<div id="post-body" class="metabox-holder columns-2">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a class="nav-link active" href="admin.php?page=fmovies_movie">Search</a>
				</li>
				<li class="nav-item">
					<a id="discover" class="nav-link" href="admin.php?page=fmovies_discover">Discover</a>
				</li>
			</ul>
			<div id="postbox-container-1" class="postbox-container">
				<div id="side-sortables" class="meta-box-sortables ui-sortable ui-sortable-disabled">
					<div id="submitdiv" class="postbox">
						<h2><span class="type">Movie Search</span></h2>
						<div class="inside">
							<form data-view="tmdb_result" data-callback="show_tmdb_search" data-method="post"
								  id="tmdb_search" class="fmovies_form">
								<div class="submitbox" id="submitpost">
									<div id="minor-publishing">
										<div id="minor-publishing-actions" style="text-align: left">

											<input type="hidden" name="page" id="page" value="1">
											<input type="hidden" id="switchvalue" value="SearchMovie" name="action">
											<input class="font-weight-normal" type="text" required autofocus
												   name="movie_title" id="movie_title"
												   style="min-width: 100%; text-align: left;"
												   placeholder="Enter Movie title">

											<label style="display:none;" class="mtt">Language</label>
											<select style="display:none;" name="language" id="language"
													style="width: 100%">
												<option value="<?php echo \APILANGUAGE; ?>" selected>Default</option>
											</select>
											<p><select class="sortby" name="action" id="switchvalue"
													   style="display: none;width: 100%">
													<option value="SearchMovie" selected>Search</option>
													<option value="Populars">Popular</option>
													<option value="Rated">Top Rated</option>
													<option value="Upcoming">Upcoming</option>
													<option value="Playing">Now Playing</option>
													<option value="Animation">Anime</option>
											</p>
											</select>
										</div>
										<div class="clear"></div>
									</div>
									<div id="major-publishing-actions">
										<div style="float:left;" class="custom-control custom-switch">
											<input type="checkbox" class="custom-control-input" id="customSwitches">
											<label class="custom-control-label" for="customSwitches">Search</label>
										</div>
										<div id="publishing-action">
											<span class="spinner"></span>
											<button type="button" id="publish"
													class="button button-cancel button-large btn btn-primary"
													style="display: none;">New Search
											</button>
											<button type="submit" id="publish"
													class="button button-primary button-large btn btn-primary">Search
											</button>
										</div>
										<div class="clear"></div>
									</div>
								</div>
							</form>
							<form data-callback="show_movie_add" data-method="post" id="tmdb_movie_add"
								  class="fmovies_form" data-view="tmdb_api">
								<input type="hidden" value="AddMovie" name="action" required>
								<input type="hidden" value="" id="tmdb_movie_id" name="tmdb_movie_id" required>
								<input type="hidden" name="tmdb_language" id="tmdb_language" value="en-US">
								<div class="tmdb_api" style="align-t"></div>
							</form>
						</div>
					</div>
				</div>
				<p class="hide-if-no-js">
					<button type="button" class="button-link" id="bulk-import" aria-expanded="false"
							style="display: none;">Bulk import
					</button>
				</p>
				<div id="tags"></div>
			</div>
			<div class="postbox-container" id="post-body">
				<div id="submitdiv" class="postbox results">
					<h2 style="text-align: center"><span>Results: <span class="result_page"></span></span>
						<p class="total"></p></h2>
					<div class="inside">
						<div class="submitbox" id="submitpost">
							<div id="minor-publishing" class="tmdb_result" style="padding: 15px;">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>
