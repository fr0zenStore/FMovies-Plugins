<?php
/*
Plugin Name: Importer Premium
Plugin URI: https://fr0zen.store
Description: MyFlixer Premium TMDB Importer plugin.
Version: 13
Author: fr0zen
Author URI: https://fr0zen.store/
License: Limited
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define("IMPORTER", plugin_basename(__FILE__));
define("PLUGIN_DIR", __DIR__);


require_once __DIR__ . '/vendor/autoload.php';

use App\Bootstrap;



if (is_admin()) {

$fmovies = new Bootstrap();
}
