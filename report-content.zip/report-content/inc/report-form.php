<?php
	global $post;
	$form_options    = get_option( 'wprc_form_settings' );
	$permissions     = get_option( 'wprc_permissions_settings' );
	$required_fields = $form_options['required_fields'];
	$reasons         = explode( "\n", $form_options['report_reasons'] );
	$release_date    = esc_html( get_post_meta( $post->ID, 'release_date', true ) );
?>
<div class="modal fade" id="report-video" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 450px">
		<div class="modal-content wprc-content">
			<div class="modal-header">
				<div class="wprc-message title"><?php echo $form_options['slidedown_button_text']; ?></div> 
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
			</div>
			<div class="description text-muted"><?php esc_html_e( 'Please let us know what\'s wrong so we can fix it as soon as possible.', 'report-content' ); ?></div>
			<div class="alert alert-danger error" style="display:none;">
				<button type="button" class="close" data-dismiss="alert"><span>×</span></button>
				<div><?php esc_html_e( 'Report data must not be empty.', 'report-content' ); ?></div>
			</div>
			<div class="thank-you" style="display:none;">
				<button type="button" class="close" data-dismiss="modal"><span>×</span></button>
				<div><?php esc_html_e( 'Thanks for your report!', 'report-content' ); ?></div>
			</div>
			<div class="" id="report_modal_body">
				<div class="wprc-form">
					<?php if ( $permissions['login_required'] && ! is_user_logged_in() ) : ?>
						<?php echo wprc_login_required_message(); ?>
					<?php else : ?>
					<div class="form-group">
						<h5 class="text-primary name"><?php the_title(); ?>
																		 <?php
																			if ( $release_date != '' ) {
																				echo ' (' . $release_date . ')'; }
																			?>
						</h5>
						<span class="episode text-muted"><?php Tipo(); ?></span>
					</div>
						<?php if ( $form_options['active_fields']['reporter_name'] ) : ?>
					<div class="form-group">
						<label for="input-name-<?php echo $post->ID; ?>">
							<?php esc_html_e( 'Your Name:', 'report-content' ); ?>
							<?php if ( $required_fields['reporter_name'] ) : ?>
							<span class="required-sign text-danger">*</span>
							<?php endif; ?>
						</label>
						<input type="text" id="input-name-<?php echo $post->ID; ?>"
						class="form-control input-name wprc-input"
							<?php
							if ( $required_fields['reporter_name'] ) :
								?>
							required<?php endif; ?>/>
					</div>
					<?php endif; ?>
						<?php if ( $form_options['active_fields']['reporter_email'] ) : ?>
					<div class="form-group">
						<label for="input-email-<?php echo $post->ID; ?>">
							<?php esc_html_e( 'Your Email:', 'report-content' ); ?>
							<?php if ( $required_fields['reporter_email'] ) : ?>
							<span class="required-sign text-danger">*</span>
							<?php endif; ?>
						</label>
						<input type="text" id="input-email-<?php echo $post->ID; ?>"
						class="form-control input-email wprc-input"
							<?php
							if ( $required_fields['reporter_email'] ) :
								?>
							required<?php endif; ?>/>
					</div>
					<?php endif; ?>
					<div class="form-group">
						<label for="input-reason-<?php echo $post->ID; ?>">
							<?php esc_html_e( 'Issue:', 'report-content' ); ?>
						</label>
						<select id="input-reason-<?php echo $post->ID; ?>" class="custom-select input-reason"
															<?php
															if ( $required_fields['reason'] ) :
																?>
							required<?php endif; ?>>
							<option selected disabled value=""><?php esc_html_e( '-- What\'s wrong --', 'report-content' ); ?></option>
							<?php foreach ( $reasons as $key => $reason ) : ?>
							<option><?php echo esc_attr( $reason ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
						<?php if ( $form_options['active_fields']['details'] ) : ?>
					<div class="form-group">
						<label for="input-details-<?php echo $post->ID; ?>">
							<?php esc_html_e( 'Please describe below', 'report-content' ); ?>
							<?php if ( $required_fields['details'] ) : ?>
							<span class="required-sign text-danger">*</span>
							<?php endif; ?>
						</label>
						<div class="options">
							<textarea id="input-details-<?php echo $post->ID; ?>"
							class="form-control input-details wprc-input"
							<?php
							if ( $required_fields['details'] ) :
								?>
								required<?php endif; ?>></textarea>
						</div>
					</div>
					<?php endif; ?>
					<div class="form-group text-center"> 
						<input type="hidden" class="post-id" value="<?php echo $post->ID; ?>">
						<button type="button" class="btn btn-primary w-100 mt-3 wprc-submit"><?php echo $form_options['submit_button_text']; ?></button> 
					</div>
					<div class="loader mt-1"><div class="loading"><div></div></div></div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
