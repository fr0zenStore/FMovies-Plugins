<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Tmdb_Importer_Helpers
 *
 * This class contains repetitive functions that
 * are used globally within the plugin.
 *
 * @package		TMDBIMPORT
 * @subpackage	Classes/Tmdb_Importer_Helpers
 * @author		fr0zen.store
 * @since		1.0.0
 */
class Tmdb_Importer_Helpers{

	/**
	 * ######################
	 * ###
	 * #### CALLABLE FUNCTIONS
	 * ###
	 * ######################
	 */

}
