<?php
/**
 * TMDB Importer
 *
 * @package       TMDBIMPORT
 * @author        fr0zen.store
 * @version       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:   TMDB Importer
 * Plugin URI:    https://mydomain.com
 * Description:   test
 * Version:       1.0.0
 * Author:        fr0zen.store
 * Author URI:    https://fr0zen.store
 * Text Domain:   tmdb-importer
 * Domain Path:   /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
// Plugin name
define( 'TMDBIMPORT_NAME',			'TMDB Importer' );

// Plugin version
define( 'TMDBIMPORT_VERSION',		'1.0.0' );

// Plugin Root File
define( 'TMDBIMPORT_PLUGIN_FILE',	__FILE__ );

// Plugin base
define( 'TMDBIMPORT_PLUGIN_BASE',	plugin_basename( TMDBIMPORT_PLUGIN_FILE ) );

// Plugin Folder Path
define( 'TMDBIMPORT_PLUGIN_DIR',	plugin_dir_path( TMDBIMPORT_PLUGIN_FILE ) );

// Plugin Folder URL
define( 'TMDBIMPORT_PLUGIN_URL',	plugin_dir_url( TMDBIMPORT_PLUGIN_FILE ) );

/**
 * Load the main class for the core functionality
 */
require_once TMDBIMPORT_PLUGIN_DIR . 'core/class-tmdb-importer.php';

/**
 * The main function to load the only instance
 * of our master class.
 *
 * @author  fr0zen.store
 * @since   1.0.0
 * @return  object|Tmdb_Importer
 */
function TMDBIMPORT() {
	return Tmdb_Importer::instance();
}

TMDBIMPORT();
